plugins {
    id("com.android.application")
}

android {
    namespace = "com.a99.cricket"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.a99.cricket"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
