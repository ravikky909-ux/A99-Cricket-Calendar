const state={matches:[],series:[],teams:[],venues:[],query:'',page:'home'};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
async function load(){
  const [m,s,t,v]=await Promise.all(['data/matches.json','data/series.json','data/teams.json','data/venues.json'].map(x=>fetch(x).then(r=>r.json())));
  const imported=JSON.parse(localStorage.getItem('a99ImportedMatches')||'null');
  state.matches=Array.isArray(imported)&&imported.length?imported:m; state.series=s;state.teams=t;state.venues=v;
  initFilters(); renderAll();
}
function go(page){state.page=page;$$('.page').forEach(x=>x.classList.toggle('active',x.dataset.page===page));$$('.bottom-nav button').forEach(x=>x.classList.toggle('active',x.dataset.go===page));scrollTo(0,0)}
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
function initFilters(){const months=[...new Set(state.matches.map(m=>m.date.slice(0,7)))].sort();months.forEach(m=>$('#monthFilter').insertAdjacentHTML('beforeend',`<option value="${m}">${new Date(m+'-01T00:00:00').toLocaleDateString('en-IN',{month:'long',year:'numeric'})}</option>`));['monthFilter','typeFilter','formatFilter'].forEach(id=>$('#'+id).addEventListener('change',renderSchedule));}
function matchHtml(m){return `<article class="match-card card">
<div class="match-top"><span class="series">${esc(m.series)}</span><span class="tag">${esc(m.category)} • ${esc(m.format)}</span></div>
<div class="teams-row"><div class="team"><div class="badge">${esc(m.team1Code)}</div>${esc(m.team1)}</div><div class="versus">VS</div><div class="team"><div class="badge">${esc(m.team2Code)}</div>${esc(m.team2)}</div></div>
<div class="meta"><span>📅 ${fmtDate(m.date)}</span><span>🕒 ${esc(m.time||'TBA')}</span><span>📍 ${esc(m.venue)}, ${esc(m.city)}</span><span class="status">${esc(m.status||'Confirmed')}</span></div></article>`}
function fmtDate(d){return new Date(d+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}
function filtered(){const q=state.query.toLowerCase(),mo=$('#monthFilter')?.value||'all',ty=$('#typeFilter')?.value||'all',fo=$('#formatFilter')?.value||'all';return state.matches.filter(m=>(!q||JSON.stringify(m).toLowerCase().includes(q))&&(mo==='all'||m.date.startsWith(mo))&&(ty==='all'||m.category===ty)&&(fo==='all'||m.format===fo)).sort((a,b)=>a.date.localeCompare(b.date));}
function renderSchedule(){const x=filtered();$('#scheduleList').innerHTML=x.length?x.map(matchHtml).join(''):`<div class="card admin-card"><b>No matching fixture</b><p class="muted">Filter ya search change kijiye.</p></div>`}
function renderTeams(){const q=state.query.toLowerCase();const arr=state.teams.filter(t=>!q||JSON.stringify(t).toLowerCase().includes(q));$('#teamsList').innerHTML=arr.map(t=>`<article class="team-card card"><div class="team-logo">${esc(t.code)}</div><b>${esc(t.name)}</b><small>${esc(t.type)} • ${(t.players||[]).length} listed players</small><p class="muted">${(t.players||[]).length?(t.players||[]).map(esc).join(', '):'Squad details will be added when officially available.'}</p></article>`).join('')}
function renderVenues(){const q=state.query.toLowerCase();const arr=state.venues.filter(v=>!q||JSON.stringify(v).toLowerCase().includes(q));$('#venuesList').innerHTML=arr.map(v=>`<article class="venue-card card"><h3>${esc(v.name)}</h3><p>📍 ${esc(v.city)}, ${esc(v.country)}</p><p>Capacity: ${esc(v.capacity||'TBA')} • Pitch: ${esc(v.pitch||'TBA')}</p></article>`).join('')}
function renderAll(){
 $('#matchCount').textContent=state.matches.length;$('#seriesCount').textContent=new Set(state.matches.map(m=>m.series)).size;$('#teamCount').textContent=state.teams.length;$('#lastUpdated').textContent='Coverage: 18 Jul–31 Aug 2026';
 const upcoming=[...state.matches].filter(m=>m.date>='2026-07-18').sort((a,b)=>a.date.localeCompare(b.date)).slice(0,5);$('#homeMatches').innerHTML=upcoming.map(matchHtml).join('');renderSchedule();renderTeams();renderVenues();
}
$('#search').addEventListener('input',e=>{state.query=e.target.value.trim();renderSchedule();renderTeams();renderVenues()});
$('#unlock').addEventListener('click',()=>{if($('#pin').value==='9999'){ $('#adminTools').classList.remove('hidden');toast('Admin unlocked');const st=JSON.parse(localStorage.getItem('a99Settings')||'{}');$('#a99Url').value=st.a99||'https://allrounder99.com/m/home';$('#r99Url').value=st.r99||'https://rajahuli99.com/home';$('#supportNumber').value=st.support||'';}else toast('Wrong PIN')});
$('#saveSettings').addEventListener('click',()=>{localStorage.setItem('a99Settings',JSON.stringify({a99:$('#a99Url').value,r99:$('#r99Url').value,support:$('#supportNumber').value}));toast('Settings saved')});
$('#importJson').addEventListener('click',()=>{try{const j=JSON.parse($('#jsonImport').value);if(!Array.isArray(j))throw 0;localStorage.setItem('a99ImportedMatches',JSON.stringify(j));state.matches=j;renderAll();toast('Fixtures imported')}catch(e){toast('Invalid JSON')}});
load().catch(()=>{document.body.innerHTML='<div style="padding:30px;color:white;font-family:sans-serif">App data could not load. Please reinstall the app.</div>'});
