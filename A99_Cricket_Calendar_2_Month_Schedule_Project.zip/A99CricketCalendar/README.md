# A99 Cricket Calendar (Offline Android project)

Professional dark-teal cricket schedule app with Allrounder99 and Rajahuli99 branding.

## Included
- Smooth branded splash screen
- No live score / live match section
- Offline fixture database
- Date/category/format filters and search
- Teams, sample player directory and venues
- Official platform buttons
- Bottom Admin icon and local on-device admin panel
- Import fixture JSON without changing source code
- Combined Allrounder99 + Rajahuli99 launcher icon

## Build
Open the project in Android Studio and run **Build > Build APK(s)**.

## Admin
Default local PIN: `9999`

## Important data note
This package includes confirmed sample fixtures available at build time and a 2026 series catalogue. It does not claim to contain every worldwide domestic fixture or final squad. Without an API or manually maintained data feed, schedules and squads cannot update automatically.

## Free GitHub APK build
Upload the project to a GitHub repository. Open **Actions > Build Android APK > Run workflow**. Download the `A99-Cricket-Calendar-APK` artifact after the workflow completes.


## Version 1.1.0 – Two-month schedule update
- Coverage: 18 July–31 August 2026
- Loaded fixtures: 121
- Series: 17
- Teams indexed: 47
- Venues indexed: 26
- New selected Allrounder99/Rajahuli99 launcher icon installed
- Added 100-ball filter and updated coverage labels
